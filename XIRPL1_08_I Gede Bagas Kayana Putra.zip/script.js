const toggleButton = document.getElementById('toggle-btn');
const body = document.body;

toggleButton.addEventListener('click', function() {
    if (body.classList.contains('mode-cerah')) {
        body.classList.replace('mode-cerah', 'mode-gelap');
        toggleButton.textContent = 'Ganti ke Mode Cerah';
    } else {
        body.classList.replace('mode-gelap', 'mode-cerah');
        toggleButton.textContent = 'Ganti ke Mode Gelap';
    }
});